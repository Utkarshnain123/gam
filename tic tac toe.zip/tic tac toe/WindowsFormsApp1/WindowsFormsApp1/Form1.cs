﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private char currentPlayer;
        private char[,] board;
        private int moves;

        public Form1()
        {
            InitializeComponent();

            InitializeGame();
        }

        private void InitializeGame()
        {
            currentPlayer = 'X';
            board = new char[3, 3];
            moves = 0;

            // Initialize buttons
            foreach (Control control in this.Controls)
            {
                if (control is Button)
                {
                    control.Text = "";
                    control.Enabled = true;
                    control.Click += new EventHandler(Button_Click);
                }
            }

            UpdateStatus();
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            int row = (button.TabIndex / 3);
            int col = (button.TabIndex % 3);

            if (board[row, col] == '\0') // Check if the cell is empty
            {
                board[row, col] = currentPlayer;
                button.Text = currentPlayer.ToString();
                moves++;

                if (CheckWinner())
                {
                    MessageBox.Show($"Player {currentPlayer} wins!");
                    DisableButtons();
                }
                else if (moves == 9)
                {
                    MessageBox.Show("It's a draw!");
                }
                else
                {
                    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                    UpdateStatus();
                }
            }
        }

        private void UpdateStatus()
        {
            lblStatus.Text = $"Player {currentPlayer}'s turn";
        }

        private bool CheckWinner()
        {
            // Check rows, columns and diagonals
            for (int i = 0; i < 3; i++)
            {
                if ((board[i, 0] == currentPlayer && board[i, 1] == currentPlayer && board[i, 2] == currentPlayer) ||
                    (board[0, i] == currentPlayer && board[1, i] == currentPlayer && board[2, i] == currentPlayer))
                {
                    return true;
                }
            }
            if ((board[0, 0] == currentPlayer && board[1, 1] == currentPlayer && board[2, 2] == currentPlayer) ||
                (board[0, 2] == currentPlayer && board[1, 1] == currentPlayer && board[2, 0] == currentPlayer))
            {
                return true;
            }
            return false;
        }

        private void DisableButtons()
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button)
                {
                    control.Enabled = false;
                }
            }
        }
    }
}